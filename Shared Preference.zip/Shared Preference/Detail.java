package com.example.root.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Detail extends AppCompatActivity {

    String MY_PREFS_NAME = "MY_SHARED_PREFERENCES";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        SharedPreferences prefs = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);

        TextView mText = (TextView) findViewById(R.id.uname);
        mText.setText("Full Name: " + prefs.getString("username", "") + " " + prefs.getString("lastname", ""));

        TextView mText1 = (TextView) findViewById(R.id.email);
        mText1.setText("Email ID: " + prefs.getString("email", ""));

        TextView mText4 = (TextView) findViewById(R.id.mnumber);
        mText4.setText("Mobile Number: " + prefs.getString("Mobile Number", ""));

        TextView mText2 = (TextView) findViewById(R.id.password);
        mText2.setText("" + prefs.getString("password", ""));

        TextView mText9 = (TextView) findViewById(R.id.Website);
        if (prefs.getString("website", "").equals(""))
            mText9.setVisibility(View.GONE);
        else
            mText9.setText("Website: " + prefs.getString("website", ""));

        TextView mText5 = (TextView) findViewById(R.id.maddress);
        mText5.setText("Address :" + prefs.getString("Address", ""));

        Button btnLogout = (Button) findViewById(R.id.btnDetails_logout);
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
                editor.putBoolean("isLoggedIn", false);
                editor.commit();

                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });


    }
}



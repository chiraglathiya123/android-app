package com.example.root.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends Activity {
    EditText etFirstName, etLastName, etEmail, etPhone, etPassword, etConfirmpassword, etWebsite, etAddress;
    CheckBox Riding, Dancing, Cricket, Swimming, Photography, Writing, Travelling, Reading, Drawing;
    Button btnSignUp, btnSignIn;

    String MY_PREFS_NAME = "MY_SHARED_PREFERENCES";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etFirstName = (EditText) findViewById(R.id.fname);
        etLastName = (EditText) findViewById(R.id.lname);
        etEmail = (EditText) findViewById(R.id.email);
        etPhone = (EditText) findViewById(R.id.mnumber);
        etPassword = (EditText) findViewById(R.id.password);
        etConfirmpassword = (EditText) findViewById(R.id.cpassword);
        etWebsite = (EditText) findViewById(R.id.website);
        etAddress = (EditText) findViewById(R.id.address);

        Reading = (CheckBox) findViewById(R.id.cbreading);
        Cricket = (CheckBox) findViewById(R.id.cbcricket);
        Dancing = (CheckBox) findViewById(R.id.cbdancing);
        Drawing = (CheckBox) findViewById(R.id.cbdrawing);
        Photography = (CheckBox) findViewById(R.id.cbphotography);
        Riding = (CheckBox) findViewById(R.id.cbriding);
        Travelling = (CheckBox) findViewById(R.id.cbtravelling);
        Swimming = (CheckBox) findViewById(R.id.cbswimming);
        Writing = (CheckBox) findViewById(R.id.cbwriting);

        btnSignIn = (Button) findViewById(R.id.btnsignIn);
        btnSignUp = (Button) findViewById(R.id.btnsignup);

        btnSignUp.setOnClickListener(new View.OnClickListener()

        {

            @Override
            public void onClick(View v) {

                Intent i = new Intent(MainActivity.this, LoginActivity.class);

                if (etFirstName.length() == 0)

                {
                    etFirstName.requestFocus();
                    etFirstName.setError("FIELD CANNOT BE EMPTY");

               /* } else if (etEmail.length() == 0) {
                    etEmail.requestFocus();
                    etEmail.setError("FIELD CANNOT BE EMPTY");
                }else if(!isValidEmail(etEmail.getText().toString())){
                    etEmail.requestFocus();
                    etEmail.setError("Please enter valid email address");
                }else if (etPassword.length() == 0) {
                    etPassword.requestFocus();
                    etPassword.setError("FIELD CANNOT BE EMPTY");
                } else if (etPassword.length() < 8) {
                    etPassword.requestFocus();
                    etPassword.setError("PASSWORD LENGTH IS MINIMUM 8-15");
                } else if (etConfirmpassword.equals(etPassword)) {
                    etConfirmpassword.requestFocus();
                    etConfirmpassword.setError("FIELD CANNOT BE EMPTY");
                } else if (etPhone.length() == 0) {
                    etPhone.requestFocus();
                    etPhone.setError("FIELD CANNOT BE EMPTY");
                } else if (etAddress.length() == 0) {
                    etAddress.requestFocus();
                    etAddress.setError("FIELD CANNOT BE EMPTY");
                } else if (etLastName.length() == 0) {
                    etLastName.requestFocus();
                    etLastName.setError("FIELD CANNOT BE EMPTY");*/
                } else {

                    SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
                    if (!etFirstName.getText().toString().equals(""))
                        editor.putString("username", etFirstName.getText().toString());
                    if (!etEmail.getText().toString().equals(""))
                        editor.putString("email", etEmail.getText().toString());
                    if (!etPassword.getText().toString().equals(""))
                        editor.putString("password", etPassword.getText().toString());
                    if (!etPhone.getText().toString().equals(""))
                        editor.putString("Mobile Number", etPhone.getText().toString());
                    if (!etAddress.getText().toString().equals(""))
                        editor.putString("Address", etAddress.getText().toString());
                    if (!etLastName.getText().toString().equals(""))
                        editor.putString("lastname", etLastName.getText().toString());
                    if (!etWebsite.getText().toString().equals(""))
                        editor.putString("website", etWebsite.getText().toString());
                    editor.commit();

                    i.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    startActivity(i);
                    finish();
                }
            }
        });
    }

    public final static boolean isValidEmail(CharSequence target) {
        if (target == null) {
            return false;
        } else {
            return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
        }
    }
}




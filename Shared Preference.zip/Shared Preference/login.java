package com.example.root.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by root on 20/6/17.
 */

public class LoginActivity extends Activity {

    String MY_PREFS_NAME = "MY_SHARED_PREFERENCES";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_login);

        final SharedPreferences prefs = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);

        if (prefs.getBoolean("isLoggedIn", false)) {

            Intent intent = new Intent(getApplicationContext(), Detail.class);
            startActivity(intent);
            finish();
        }

        final EditText etEmail, etPassword;
        Button btnLogin, btnSignup;

        etEmail = (EditText) findViewById(R.id.etLogin_email);
        etPassword = (EditText) findViewById(R.id.etLogin_password);

        btnLogin = (Button) findViewById(R.id.btnLogin_login);
        btnSignup = (Button) findViewById(R.id.btnLogin_signup);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (etEmail.getText().toString().equals("")) {

                    etEmail.requestFocus();
                    etEmail.setError("Please enter email");

                } else if (etPassword.getText().toString().equals("")) {

                    etPassword.requestFocus();
                    etPassword.setError("Please enter password");

                } else {

                    if (prefs.getString("email", "").equals(etEmail.getText().toString())) {

                        if (prefs.getString("password", "").equals(etPassword.getText().toString())) {

                            SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
                            editor.putBoolean("isLoggedIn", true);
                            editor.commit();

                            Intent intent = new Intent(getApplicationContext(), Detail.class);
                            startActivity(intent);
                            finish();

                        } else {

                            Toast.makeText(LoginActivity.this, "Wrong Password!", Toast.LENGTH_SHORT).show();
                        }
                    } else {

                        Toast.makeText(LoginActivity.this, "This email not found in our record", Toast.LENGTH_SHORT).show();

                    }
                }


            }
        });

        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

    }
}

